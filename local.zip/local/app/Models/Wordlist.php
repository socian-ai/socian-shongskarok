<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Wordlist extends Model
{
    protected $table = 'wordlists';
    public $timestamps = false;
}

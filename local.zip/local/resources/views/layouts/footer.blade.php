<script src="{{ URL::to('plugins/bower_components/jquery/dist/jquery.min.js') }}"></script>
<script src="{{ URL::to('bootstrap/dist/js/bootstrap.min.js') }}"></script>

<script src="{{ URL::to('plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js') }}"></script>
<script src="{{ URL::to('js/jquery.slimscroll.js') }}"></script>
<script src="{{ URL::to('js/waves.js') }}"></script>
<script src="{{ URL::to('plugins/bower_components/waypoints/lib/jquery.waypoints.js') }}"></script>
<script src="{{ URL::to('plugins/bower_components/counterup/jquery.counterup.min.js') }}"></script>
<script src="{{ URL::to('plugins/bower_components/raphael/raphael-min.js') }}"></script>
<script src="{{ URL::to('plugins/bower_components/morrisjs/morris.js') }}"></script>
<script src="{{ URL::to('js/custom.min.js') }}"></script>
<script src="{{ URL::to('js/dashboard1.js') }}"></script>
<script src="{{ URL::to('plugins/bower_components/jquery-sparkline/jquery.sparkline.min.js') }}"></script>
<script src="{{ URL::to('plugins/bower_components/jquery-sparkline/jquery.charts-sparkline.js') }}"></script>
<script src="{{ URL::to('plugins/bower_components/toast-master/js/jquery.toast.js') }}"></script>


<script type="text/javascript">

    $(document).ready(function() {
        $.toast({
            heading: 'Welcome {{--{{ $name }}--}}',
            text: 'Let\'s make the world a better place',
            position: 'top-right',
            loaderBg:'#f47920',
            icon: 'info',
            hideAfter: 2500,

            stack: 6
        })
    });
</script>

<script src="{{ URL::to('plugins/bower_components/styleswitcher/jQuery.style.switcher.js') }}"></script>
